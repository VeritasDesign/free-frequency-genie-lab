const $=id=>document.getElementById(id),canvas=$('spectrum'),ctx=canvas.getContext('2d');let audio,analyser,stream,source,raf,last=0,generation=0;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function band(data,rate,lo,hi){const hz=rate/2/data.length,a=Math.max(1,Math.floor(lo/hz)),b=Math.min(data.length-1,Math.ceil(hi/hz));let sum=0,max=-Infinity,idx=a;for(let i=a;i<=b;i++){const p=Math.pow(10,data[i]/10);sum+=p;if(data[i]>max){max=data[i];idx=i}}return {power:10*Math.log10(sum/Math.max(1,b-a+1)),peak:idx*hz,max}}
function classify(db,lo,mi,hi,pk,flat){if(db<-58)return ['LOW SIGNAL','Microphone signal is low; absolute room noise cannot be inferred without calibration.',92];if(lo.power>mi.power+7&&pk<180)return ['LOW RUMBLE','Low-frequency energy dominates; possible HVAC, traffic, machinery, or handling noise.',78];if(pk>45&&pk<75&&lo.max>mi.power+2)return ['MAINS HUM','A strong low tone is near 50/60 Hz. Check electrical equipment or transformers.',72];if(hi.power>mi.power+5)return ['HIGH-FREQUENCY HISS','High-frequency energy dominates; possible airflow, electronics, spray, or friction.',74];if(flat<5)return ['BROADBAND NOISE','Energy is spread broadly; possible fan, airflow, road noise, or many mixed sources.',70];if(mi.power>lo.power-4&&mi.power>hi.power+2)return ['VOICE / ACTIVITY','Mid-frequency energy is strongest; speech or nearby activity is plausible.',65];return ['MIXED ROOM NOISE','No single spectral pattern dominates. Multiple sources may be present.',55]}
function draw(data){const w=canvas.width,h=canvas.height;ctx.fillStyle='#080a0b';ctx.fillRect(0,0,w,h);ctx.strokeStyle='#252b2e';ctx.lineWidth=1;for(let i=1;i<8;i++){ctx.beginPath();ctx.moveTo(i*w/8,0);ctx.lineTo(i*w/8,h);ctx.stroke()}for(let i=1;i<5;i++){ctx.beginPath();ctx.moveTo(0,i*h/5);ctx.lineTo(w,i*h/5);ctx.stroke()}ctx.strokeStyle='#f5c400';ctx.lineWidth=3;ctx.beginPath();for(let x=0;x<w;x++){const i=Math.floor(Math.pow(x/w,2)*data.length),y=clamp((data[i]+100)/100,0,1),py=h-y*h;(x?ctx.lineTo(x,py):ctx.moveTo(x,py))}ctx.stroke()}
// Web Audio time-domain floats use full-scale sample amplitude 1.0 as their reference.
// Both readings are relative digital dBFS; neither is calibrated sound-pressure level.
function measureDbfs(samples) {
  if (!samples.length) return null;
  let squared = 0, peak = 0;
  for (const sample of samples) {
    if (!Number.isFinite(sample)) return null;
    squared += sample * sample;
    peak = Math.max(peak, Math.abs(sample));
  }
  const rms = Math.sqrt(squared / samples.length);
  return {
    rmsDbfs: rms === 0 ? -Infinity : 20 * Math.log10(rms),
    peakDbfs: peak === 0 ? -Infinity : 20 * Math.log10(peak)
  };
}
function displayDbfs(value) { return value === -Infinity ? '−∞' : value.toFixed(1); }
function resetLevels() {
  $('db').textContent = '--';
  $('samplePeak').textContent = 'Sample peak -- dBFS';
  $('bar').style.width = '0%';
}
function tick(t, run) {
  if (run !== generation || !analyser || !audio) return;
  raf = requestAnimationFrame(next => tick(next, run));
  if (t - last < 100) return;
  last = t;
  const freq = new Float32Array(analyser.frequencyBinCount);
  const time = new Float32Array(analyser.fftSize);
  analyser.getFloatFrequencyData(freq);
  analyser.getFloatTimeDomainData(time);
  const level = measureDbfs(time);
  if (!level) { resetLevels(); $('note').textContent = 'Microphone samples unavailable.'; return; }
  const db = level.rmsDbfs, rate = audio.sampleRate;
  const lo = band(freq, rate, 20, 250), mi = band(freq, rate, 250, 2000);
  const hi = band(freq, rate, 2000, 10000), all = band(freq, rate, 20, 10000);
  let mean = 0, n = 0;
  for (const x of freq) if (Number.isFinite(x)) { mean += x; n++; }
  mean /= n || 1;
  let variance = 0;
  for (const x of freq) if (Number.isFinite(x)) variance += (x - mean) ** 2;
  const flat = Math.sqrt(variance / (n || 1));
  const [kind, note, confidence] = classify(db, lo, mi, hi, all.peak, flat);
  $('db').textContent = displayDbfs(db);
  $('samplePeak').textContent = `Sample peak ${displayDbfs(level.peakDbfs)} dBFS`;
  $('bar').style.width = clamp((db + 70) / 60 * 100, 0, 100) + '%';
  $('low').textContent = Math.round(lo.power);
  $('mid').textContent = Math.round(mi.power);
  $('high').textContent = Math.round(hi.power);
  $('peak').textContent = Math.round(all.peak); // Existing spectral peak, in Hz.
  $('kind').textContent = kind;
  $('confidence').textContent = `Pattern confidence ${confidence}%`;
  $('note').textContent = note;
  draw(freq);
}
function releaseMicrophone(acquiredStream, openedAudio, openedSource) {
  openedSource?.disconnect();
  acquiredStream?.getTracks().forEach(track => track.stop());
  if (openedAudio) Promise.resolve(openedAudio.close()).catch(() => {});
}
async function start() {
  // Disable repeated requests immediately, including while permission is pending.
  if ($('start').disabled) return;
  const run = ++generation;
  $('start').disabled = true;
  $('stop').disabled = false;
  $('status').textContent = '● REQUESTING MIC';
  $('status').className = '';
  let acquiredStream, openedAudio, openedSource;
  try {
    acquiredStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      video: false
    });
    if (run !== generation) { releaseMicrophone(acquiredStream); return; }
    openedAudio = new AudioContext();
    await openedAudio.resume();
    if (run !== generation) { releaseMicrophone(acquiredStream, openedAudio); return; }
    const openedAnalyser = openedAudio.createAnalyser();
    openedAnalyser.fftSize = 4096;
    openedAnalyser.smoothingTimeConstant = .78;
    openedSource = openedAudio.createMediaStreamSource(acquiredStream);
    openedSource.connect(openedAnalyser); // No connection to speakers or network.
    stream = acquiredStream; audio = openedAudio; source = openedSource; analyser = openedAnalyser;
    last = 0;
    $('status').textContent = '● LIVE';
    $('status').className = 'live';
    $('permissionNote').textContent = 'LIVE ANALYSIS · Audio stays on this device and is never recorded or uploaded.';
    tick(0, run);
  } catch (error) {
    releaseMicrophone(acquiredStream, openedAudio, openedSource);
    if (run !== generation) return; // A newer session owns the display.
    stream = audio = source = analyser = undefined;
    $('start').disabled = false;
    $('stop').disabled = true;
    $('status').textContent = '● IDLE';
    $('status').className = '';
    $('kind').textContent = 'BLOCKED';
    $('confidence').textContent = 'No live measurement';
    $('note').textContent = 'Microphone unavailable: ' + error.message;
    resetLevels();
  }
}
function stop() {
  ++generation; // Invalidate pending permission/resume and any late animation frames.
  cancelAnimationFrame(raf);
  releaseMicrophone(stream, audio, source);
  stream = audio = source = analyser = undefined;
  $('start').disabled = false;
  $('stop').disabled = true;
  $('status').textContent = '● IDLE';
  $('status').className = '';
  $('permissionNote').textContent = 'MEASUREMENT STOPPED · No live microphone readings. Nothing recorded or uploaded.';
  $('kind').textContent = 'STANDBY';
  $('confidence').textContent = 'Measurement stopped';
  $('note').textContent = 'Press START MEASUREMENT and allow microphone access.';
  resetLevels();
}
$('start').onclick=start;$('stop').onclick=stop;
