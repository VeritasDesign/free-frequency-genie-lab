export default function handler(request, response) {
  const requested = Number(request.query.bytes || 262144);
  const bytes = Math.min(Math.max(requested, 65536), 4194304);
  const block = Buffer.alloc(bytes, 97);
  response.setHeader("Content-Type", "application/octet-stream");
  response.setHeader("Content-Length", String(bytes));
  response.setHeader("Cache-Control", "no-store, max-age=0");
  response.status(200).send(block);
}
