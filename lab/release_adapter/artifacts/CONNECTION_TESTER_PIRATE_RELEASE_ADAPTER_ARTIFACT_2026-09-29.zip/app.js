const $ = (id) => document.getElementById(id);
const state = { running: false, controller: null, result: null };
const HISTORY_KEY = "free-frequency-cfi-history-v1";

const ui = {
  run: $("runButton"), settings: $("settingsButton"), settingsPanel: $("settingsPanel"),
  downloadToggle: $("downloadToggle"), statusDot: $("statusDot"), statusText: $("statusText"),
  statusDetail: $("statusDetail"), progress: $("progressBar"), score: $("score"),
  summary: $("summary"), grade: $("grade"), gradeDetail: $("gradeDetail"), needle: $("meterNeedle"),
  latency: $("latency"), jitter: $("jitter"), download: $("download"), stability: $("stability"),
  activities: $("activities"), save: $("saveButton"), label: $("labelInput"), history: $("history")
};

function setStage(stage, progress, detail) {
  const stages = ["Prepare", "Latency", "Download", "Review"];
  const ids = ["stagePrepare", "stageLatency", "stageDownload", "stageReview"];
  const active = stages.indexOf(stage);
  ids.forEach((id, index) => {
    $(id).className = index < active ? "complete" : index === active ? "active" : "";
  });
  ui.progress.style.width = `${progress}%`;
  ui.statusDetail.textContent = detail;
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function mean(values) { return values.reduce((sum, value) => sum + value, 0) / values.length; }

async function timedFetch(url, options = {}) {
  const started = performance.now();
  const response = await fetch(url, { cache: "no-store", signal: state.controller.signal, ...options });
  if (!response.ok && response.status !== 204) throw new Error(`HTTP ${response.status}`);
  return { response, elapsed: performance.now() - started };
}

async function measureLatency() {
  const samples = [];
  let failures = 0;
  for (let index = 0; index < 12; index += 1) {
    try {
      const { elapsed } = await timedFetch(`/api/ping?t=${Date.now()}-${index}`);
      samples.push(elapsed);
    } catch (error) {
      if (error.name === "AbortError") throw error;
      failures += 1;
    }
    setStage("Latency", 12 + Math.round(((index + 1) / 12) * 40), `Collecting response sample ${index + 1} of 12…`);
  }
  if (samples.length < 4) throw new Error("Not enough successful latency samples.");
  const latency = median(samples);
  const jitter = samples.length > 1 ? mean(samples.slice(1).map((value, index) => Math.abs(value - samples[index]))) : 0;
  return { latency, jitter, failures, attempts: 12 };
}

async function measureDownload() {
  let bytes = 262144;
  let best = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const started = performance.now();
    const response = await fetch(`/api/speed?bytes=${bytes}&t=${Date.now()}`, { cache: "no-store", signal: state.controller.signal });
    if (!response.ok) throw new Error(`Download HTTP ${response.status}`);
    const data = await response.arrayBuffer();
    const elapsed = performance.now() - started;
    best = { bytes: data.byteLength, elapsed, mbps: (data.byteLength * 8) / (elapsed / 1000) / 1_000_000 };
    setStage("Download", 58 + (attempt + 1) * 10, `Measuring transfer with ${(bytes / 1048576).toFixed(2)} MB…`);
    if (elapsed >= 350 || bytes >= 4194304) break;
    bytes = Math.min(bytes * 4, 4194304);
  }
  return best;
}

function calculateScore({ latency, jitter, download, stability }) {
  const latencyScore = Math.max(0, 100 - Math.max(0, latency - 20) * 0.45);
  const jitterScore = Math.max(0, 100 - jitter * 1.5);
  const speedScore = download == null ? 75 : Math.min(100, 35 + Math.log10(Math.max(download, 0.1) + 1) * 30);
  return Math.round(latencyScore * .40 + jitterScore * .22 + speedScore * .23 + stability * .15);
}

function verdict(name, detail, level) { return `<div class="activity"><div><strong>${name}</strong><small>${detail}</small></div><span class="verdict ${level}">${level}</span></div>`; }

function renderActivities(result) {
  const down = result.download;
  const browsing = result.latency < 250 && (down == null || down >= 1) ? (result.latency < 120 ? "good" : "usable") : "poor";
  const streaming = down == null ? "usable" : down >= 25 ? "good" : down >= 5 ? "usable" : "poor";
  const calls = result.latency < 150 && result.jitter < 30 ? "good" : result.latency < 300 && result.jitter < 50 ? "usable" : "poor";
  const gaming = result.latency < 60 && result.jitter < 20 ? "good" : result.latency < 130 && result.jitter < 35 ? "usable" : "poor";
  ui.activities.innerHTML = [
    verdict("Browsing", `${Math.round(result.latency)} ms response${down == null ? "" : ` · ${down.toFixed(1)} Mbps`}`, browsing),
    verdict("HD streaming", down == null ? "Download test disabled" : `${down.toFixed(1)} Mbps measured`, streaming),
    verdict("Video calls", `${Math.round(result.latency)} ms latency · ${Math.round(result.jitter)} ms jitter`, calls),
    verdict("Online gaming", `${Math.round(result.latency)} ms latency · ${Math.round(result.jitter)} ms jitter`, gaming)
  ].join("");
}

function renderResult(result) {
  const score = calculateScore(result);
  result.score = score;
  const grade = score >= 80 ? ["STRONG", "good", "Well suited to most common uses"] : score >= 55 ? ["USABLE", "usable", "Some demanding uses may vary"] : ["LIMITED", "poor", "Connection conditions need attention"];
  ui.score.textContent = score;
  ui.latency.textContent = Math.round(result.latency);
  ui.jitter.textContent = Math.round(result.jitter);
  ui.download.textContent = result.download == null ? "OFF" : result.download.toFixed(1);
  ui.stability.textContent = result.stability.toFixed(1);
  ui.summary.textContent = `${score}/100 from ${Math.round(result.latency)} ms latency, ${Math.round(result.jitter)} ms jitter${result.download == null ? "" : ` and ${result.download.toFixed(1)} Mbps down`}.`;
  ui.grade.textContent = grade[0]; ui.grade.className = `grade ${grade[1]}`; ui.gradeDetail.textContent = grade[2];
  ui.needle.hidden = false; ui.needle.style.left = `${score}%`;
  renderActivities(result);
  ui.save.disabled = false;
  state.result = result;
}

async function runTest() {
  if (state.running) { state.controller.abort(); return; }
  state.running = true; state.controller = new AbortController(); state.result = null;
  ui.run.textContent = "Cancel test"; ui.run.classList.add("cancel"); ui.save.disabled = true;
  ui.statusDot.className = "status-dot running"; ui.statusText.textContent = "MEASUREMENT IN PROGRESS";
  setStage("Prepare", 5, "Preparing a fresh measurement…");
  try {
    await new Promise((resolve) => setTimeout(resolve, 220));
    setStage("Latency", 12, "Beginning response-time sampling…");
    const network = await measureLatency();
    let transfer = null;
    let transferFailed = false;
    if (ui.downloadToggle.checked) {
      setStage("Download", 58, "Beginning adaptive download measurement…");
      try { transfer = await measureDownload(); } catch (error) {
        if (error.name === "AbortError") throw error;
        transferFailed = true;
      }
    } else {
      setStage("Download", 86, "Download measurement disabled.");
    }
    setStage("Review", 94, "Checking and interpreting the completed samples…");
    const attempts = network.attempts + (ui.downloadToggle.checked ? 1 : 0);
    const failures = network.failures + (transferFailed ? 1 : 0);
    const result = {
      timestamp: new Date().toISOString(), latency: network.latency, jitter: network.jitter,
      download: transfer?.mbps ?? null, stability: ((attempts - failures) / attempts) * 100
    };
    renderResult(result);
    setStage("Review", 100, "Measurement complete. Results are ready to review.");
    ui.statusDot.className = "status-dot"; ui.statusText.textContent = "MEASUREMENT COMPLETE";
  } catch (error) {
    if (error.name === "AbortError") {
      ui.statusText.textContent = "MEASUREMENT CANCELLED"; ui.statusDetail.textContent = "No partial result was saved.";
    } else {
      ui.statusText.textContent = "MEASUREMENT FAILED"; ui.statusDetail.textContent = error.message || "The test could not complete.";
    }
    ui.statusDot.className = "status-dot error";
  } finally {
    state.running = false; ui.run.textContent = "Run full test"; ui.run.classList.remove("cancel");
  }
}

function getHistory() {
  try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]"); } catch { return []; }
}

function renderHistory() {
  const items = getHistory();
  if (!items.length) { ui.history.innerHTML = '<div class="empty-state">No results saved on this device.</div>'; return; }
  ui.history.innerHTML = items.map((item) => {
    const when = new Date(item.timestamp).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
    const details = `${Math.round(item.latency)} ms latency · ${Math.round(item.jitter)} ms jitter${item.download == null ? "" : ` · ${item.download.toFixed(1)} Mbps`}`;
    return `<div class="history-item"><div><strong>${escapeHtml(item.label || "Unlabeled test")}</strong><small>${when}<br>${details}</small></div><div class="history-score">${item.score}</div></div>`;
  }).join("");
}

function escapeHtml(text) { const element = document.createElement("div"); element.textContent = text; return element.innerHTML; }

function saveResult() {
  if (!state.result) return;
  const items = getHistory();
  items.unshift({ ...state.result, label: ui.label.value.trim() });
  localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 10)));
  ui.label.value = ""; renderHistory();
}

function renderConnectionContext() {
  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  $("connectionType").textContent = connection?.effectiveType ? connection.effectiveType.toUpperCase() : "Not reported";
  $("browserEstimate").textContent = Number.isFinite(connection?.downlink) ? `${connection.downlink} Mbps` : "Not reported";
  $("saveData").textContent = typeof connection?.saveData === "boolean" ? (connection.saveData ? "On" : "Off") : "Not reported";
  $("onlineState").textContent = navigator.onLine ? "Online" : "Offline";
}

ui.run.addEventListener("click", runTest);
ui.settings.addEventListener("click", () => {
  const opening = ui.settingsPanel.hidden;
  ui.settingsPanel.hidden = !opening; ui.settings.setAttribute("aria-expanded", String(opening));
});
ui.save.addEventListener("click", saveResult);
$("clearButton").addEventListener("click", () => { localStorage.removeItem(HISTORY_KEY); renderHistory(); });
window.addEventListener("online", renderConnectionContext); window.addEventListener("offline", renderConnectionContext);
renderConnectionContext(); renderHistory();
